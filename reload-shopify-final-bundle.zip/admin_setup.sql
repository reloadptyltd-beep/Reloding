-- Admin user setup for Supabase
-- Replace 'email@example.com' with your admin email (Reload.pty.ltd@gmail.com)
-- Run this in Supabase SQL editor after you have a user with that email in auth.users

-- 1) Find the user's id
select id from auth.users where email = 'Reload.pty.ltd@gmail.com';

-- Suppose the id returned is: '00000000-0000-0000-0000-000000000000'
-- 2) Insert or update profiles table to ensure admin exists
insert into profiles (id, full_name, paypal_email, balance_cents)
values ('00000000-0000-0000-0000-000000000000', 'Reload Admin', 'Reload.pty.ltd@gmail.com', 0)
on conflict (id) do update set full_name = excluded.full_name;

-- 3) (Optional) Add a simple role marker in a new table
create table if not exists roles (user_id uuid primary key references auth.users, role text);
insert into roles (user_id, role) values ('00000000-0000-0000-0000-000000000000', 'admin')
on conflict (user_id) do update set role = 'admin';
